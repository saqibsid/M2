from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class SpecialSkills(models.Model):
    name = models.CharField(max_length=100,null=True,blank=True)  #can be null,blank:it is ok if user inputs nothing
    description = models.CharField(max_length=100,null=True,blank=True)
    updated_at = models.DateTimeField(auto_now=True)            #time when it was updated
    created_at = models.DateTimeField(auto_now_add=True)        #time when it was created


    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = 'Special Skills'        #used when we dont want 's' in the end which is been added by default in the db

class Project(models.Model):

    Pchoices = [        #refer django choices documentation
        ('High Priority','High Priority'),
        ('Low Priority','Low Priority'),
    ]
    
    name = models.CharField(max_length=100)
    priority = models.CharField(choices=Pchoices,null=False,max_length=20,default='Low Priority')
    description = models.CharField(max_length=400)
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name + ' ' + self.link
    class Meta:
        verbose_name_plural = 'Task'




class Profile(models.Model):
    userName = models.OneToOneField(User, on_delete=models.CASCADE)
    bio = models.TextField()
    department = models.CharField(max_length=50,null=False)
    workex = models.IntegerField(null=False)
    position = models.CharField(max_length=50,null=False)

    def __str__(self):
        return self.userName.username