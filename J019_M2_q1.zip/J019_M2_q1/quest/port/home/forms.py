from dataclasses import field
from socket import fromshare
from django.contrib.auth.models import User
from django import forms
from .models import Project,Profile

# class ProjectForms(forms.Form):
#     first_name = forms.CharField(max_length=100)
#     last_name = forms.CharField(max_length=100)
#     roll = forms.CharField(max_length=100)

class ProjectForms(forms.ModelForm):
    class Meta:
        model = Project
        fields = '__all__'
        #fields = ['name','techStack']

class SignUp(forms.ModelForm):
    class Meta:
        model = User
        fields = '__all__'

class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = '__all__'

