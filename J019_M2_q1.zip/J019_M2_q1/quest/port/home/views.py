import imp
from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import SpecialSkills,Project,Profile
from .forms import ProjectForms,SignUp,ProfileForm
from django.contrib import messages
from django.contrib.auth import login,logout,authenticate   #for LOGIN
from django.contrib.auth.models import User     #for USER AUTHENTICATION
from django.contrib.auth.decorators import login_required,permission_required   #IMPORTANT
#the above login_required decorator will give access to only those who have logged in
# Create your views here.
def home(request):
    try:           #if this fails then the except block code will be executed
        data = SpecialSkills.objects.all()    #it will return all the data in it
        # print(data[0])         #as it is stored as a list,we can access it using indexing
        context = {'special':data}
    except Exception as e:
         context = {'special':'Data Not FOund'}
    
    return render(request,'index.html',context)

# @login_required(login_url='login')  #if not logged in then it will take you to login page
def DailyTask(request):
    try:          
        data = Project.objects.all()    
        context = {'DailyTask':data}
    except Exception as e:
         context = {'DailyTask':'Data Not FOund'}
    return render(request,'projects.html',context)

# @login_required(login_url='login')
def dashboard(request):
    try:          
        data = Profile.objects.all()    
        context = {'data1':data}
    except Exception as e:
         context = {'data1':'Data Not FOund'}
    return render(request,'dashboard.html')

def projectDetails(request,hm):
    print(hm)
    #fetchData = Project.objects.filter(name=hm)   #will return list of objects
    fetchData = Project.objects.get(name=hm)
    # print(fetchData.query)
    # print(fetchData)
    context = {}
    #context = {'fetchData':fetchData}
    return render(request,'proj_detail.html',context)

def Taskadd(request):
    form = ProjectForms
    if request.method =='POST':
        myData = ProjectForms(request.POST)
        if myData.is_valid():
            myData.save()
            messages.success(request,'Task added successfully')
            return redirect('DailyTask')

    context = {'form':form}
    return render(request,'projAdd.html',context)

def Taskdelete(request, id):
    data = Project.objects.get(id=id)
    data.delete()
    messages.warning(request,'Task Deleted')
    return redirect('DailyTask')


# @permission_required('home.update_profile',login_url='Home')  #syntax: ('appName.property',redirect to)
def Taskupdate(request, id):
    mydata = Project.objects.get(id=id)
    updateform = ProjectForms(request.POST or None,instance=mydata)
    
    if updateform.is_valid():
        updateform.save()
        messages.success(request,'Task Updated Successfully')
        return redirect('DailyTask')
    context = {"form":updateform}

    return render(request,'projectUpdate.html',context)

def loginpage(request):
    if request.method == 'POST':
        name = request.POST['username']
        password = request.POST['pass']
        user = authenticate(request,username=name,password=password)   #checks if the user already exists or not
        #if does not exist then user will return none, else if exists then the username will be returned
        # print(user)
        if user is not None:
            login(request,user)
            return redirect('Home')
        else:
            messages.warning(request,'Invalid credentials!!')
            return redirect('login')

    return render(request,'login.html')

def logoutpage(request):
    print('Logged out')
    logout(request)
    return redirect('Home')    #as we are redirecting it to the home page

def signup(request):
    if request.method == 'POST':
        form = SignUp(request.POST)
        if form.is_valid():
            user = form.save()
            user.refresh_from_db()  
            # load the profile instance created by the signal
            user.save()
            raw_password = form.cleaned_data.get('password1')

            # login user after signing up
            user = authenticate(username=user.username, password=raw_password)
            login(request, user)

            # redirect user to home page
            return redirect('Home')
    else:
        form = SignUp()
    return render(request, 'signup.html', {'form': form})

def profileadd(request):
    form = ProfileForm
    if request.method =='POST':
        myData = ProfileForm(request.POST)
        if myData.is_valid():
            myData.save()
            messages.success(request,'Task added successfully')
            return redirect('Dashboard')

    context = {'form':form}
    return render(request,'ProfileAdd.html',context)